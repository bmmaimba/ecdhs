
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime

class HousingProject(models.Model):
    _name = 'housing.project'
    _description = 'Housing Project'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'

    name = fields.Char('Project Name', required=True, tracking=True)
    reference = fields.Char('Reference', readonly=True, copy=False)
    project_type = fields.Selection([
        ('irdp', 'Integrated Residential Development'),
        ('uisp', 'Informal Settlement Upgrade'),
        ('rural', 'Rural Subsidy')
    ], required=True, tracking=True)

    # Basic Information
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company)
    municipality_id = fields.Many2one('res.partner', domain=[('is_municipality', '=', True)], tracking=True)
    start_date = fields.Date('Start Date', tracking=True)
    end_date = fields.Date('Expected End Date', tracking=True)
    actual_end_date = fields.Date('Actual End Date', readonly=True, tracking=True)

    # Status and Approvals
    state = fields.Selection([
        ('draft', 'Draft'),
        ('feasibility', 'Feasibility Study'),
        ('planning', 'Planning'),
        ('implementation', 'Implementation'),
        ('completion', 'Completed'),
        ('cancelled', 'Cancelled')
    ], default='draft', tracking=True)

    # Financial Information
    budget_allocation = fields.Float('Budget Allocation', tracking=True)
    spent_amount = fields.Float('Spent Amount', compute='_compute_spent_amount', store=True)
    remaining_budget = fields.Float('Remaining Budget', compute='_compute_remaining_budget', store=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id)
    analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic Account')

    # Documents
    feasibility_report = fields.Binary('Feasibility Report')
    feasibility_filename = fields.Char('Feasibility Report Filename')
    environmental_impact = fields.Binary('EIA Report')
    environmental_filename = fields.Char('EIA Report Filename')
    project_description = fields.Text('Project Description')

    # Relationships
    beneficiary_ids = fields.One2many('housing.beneficiary', 'project_id', string='Beneficiaries')
    services_ids = fields.One2many('housing.services', 'project_id', string='Services')
    document_ids = fields.One2many('housing.support', 'project_id', string='Documents')

    # Statistics
    beneficiary_count = fields.Integer(compute='_compute_beneficiary_count', store=True)
    services_count = fields.Integer(compute='_compute_services_count', store=True)

    @api.model
    def create(self, vals):
        if 'reference' not in vals:
            vals['reference'] = self.env['ir.sequence'].next_by_code('housing.project')
        return super(HousingProject, self).create(vals)

    @api.depends('beneficiary_ids')
    def _compute_beneficiary_count(self):
        for record in self:
            record.beneficiary_count = len(record.beneficiary_ids)

    @api.depends('services_ids')
    def _compute_services_count(self):
        for record in self:
            record.services_count = len(record.services_ids)

    @api.depends('budget_allocation', 'spent_amount')
    def _compute_remaining_budget(self):
        for record in self:
            record.remaining_budget = record.budget_allocation - record.spent_amount

    def action_set_to_draft(self):
        self.write({'state': 'draft'})

    def action_start_feasibility(self):
        self.write({'state': 'feasibility'})

    def action_start_planning(self):
        if not self.feasibility_report:
            raise UserError(_('Please upload the feasibility report before proceeding to planning.'))
        self.write({'state': 'planning'})

    def action_start_implementation(self):
        if not self.environmental_impact:
            raise UserError(_('Please upload the Environmental Impact Assessment report before implementation.'))
        self.write({'state': 'implementation'})

    def action_complete(self):
        self.write({
            'state': 'completion',
            'actual_end_date': fields.Date.today()
        })

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for record in self:
            if record.start_date and record.end_date and record.start_date > record.end_date:
                raise ValidationError(_('Start date must be before end date.'))

    def unlink(self):
        for record in self:
            if record.state not in ('draft', 'cancelled'):
                raise UserError(_('You can only delete draft or cancelled projects.'))
        return super(HousingProject, self).unlink()

    @api.model
    def get_dashboard_data(self):
        return {
            'total_projects': self.search_count([]),
            'active_projects': self.search_count([('state', 'not in', ['completed', 'cancelled'])]),
            'total_beneficiaries': self.env['housing.beneficiary'].search_count([]),
            'total_budget': sum(self.search([]).mapped('budget_allocation')),
            'project_types': {
                'irdp': self.search_count([('project_type', '=', 'irdp')]),
                'uisp': self.search_count([('project_type', '=', 'uisp')]),
                'rural': self.search_count([('project_type', '=', 'rural')])
            }
        }
